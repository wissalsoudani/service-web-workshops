package esprit.sw.resources;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;



@Path("greetings")
public class HelloRessource {

//	@GET
//	@Produces(MediaType.TEXT_PLAIN)
//	public String sayHello()
//	{
//		return "hellooo";
//	}

	@GET
	@Path("{FirstName}/{LastName}")
	@Produces(MediaType.TEXT_PLAIN)
	public String sayHelloQueryParam(@PathParam(value="FirstName")String prenom,@PathParam(value="LastName")String nom)
	{
		return "Hello : "+prenom+ " " +nom;
	}
//	
//	@GET
//	@Path("{FirstName}/{LastName}")
//	@Produces(MediaType.TEXT_PLAIN)
//	public String sayHelloPathParam(@PathParam(value="FirstName")String prenom,@PathParam(value="LastName")String nom)
//	{
//		return "Hello : "+prenom+ " " +nom;
//	}
	
//	@GET
	//@Produces(MediaType.TEXT_PLAIN)
//	public String sayHelloAll(@QueryParam(value="FirstName")String prenom,@QueryParam(value="LastName")String nom)
//	{
//		if (nom !=null && prenom !=null)
	//	return "Hello From Jax-RS Mr/Ms : "+prenom+ " " +nom;
//	return "Hello From Jax-RS";
	//}
}
