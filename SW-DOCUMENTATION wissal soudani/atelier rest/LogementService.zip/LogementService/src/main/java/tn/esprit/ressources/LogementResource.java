package tn.esprit.ressources;


import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import tn.esprit.business.LogementBusiness;
import tn.esprit.entites.Logement;
import tn.esprit.entites.Logement.Type;
@Api
@Path(value="logements")
public class LogementResource {
	static LogementBusiness metier=new LogementBusiness();



	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public List<Logement> getLogements(){
		List<Logement> liste=metier.getLogements();
		return liste;
	}

	@GET
	@Path(value="deleguation/{deleguation}")
	@Produces({ MediaType.APPLICATION_JSON })
	public List<Logement> getLogementsByDeleguation(@PathParam(value="deleguation")String deleguation){
		List<Logement> liste=metier.getLogementsByDeleguation(deleguation);
		return liste;
	}

	@GET
	@Path(value="gouvernorat/{gouvernorat}")
	@Produces({ MediaType.APPLICATION_JSON })
	public List<Logement> getLogementsByGouvernorat(@PathParam(value="gouvernorat")String gouvernorat){
		List<Logement> liste=metier.getLogementsByGouvernorat(gouvernorat);
		return liste;
	}



	@GET
	@Path(value="type/{type}")
	@Produces({ MediaType.APPLICATION_JSON })
	public List<Logement> getLogementsByType(@PathParam(value="type")Type type){
		List<Logement> liste=metier.getLogementsByType(type);
		return liste;
	}

	@GET
	@Path(value="prix/{prix}")
	@Produces({ MediaType.APPLICATION_JSON })
	public List<Logement> getLogementsByPrix(@PathParam(value="prix")float prix){
		List<Logement> liste=metier.getLogementsByPrix(prix);
		return liste;
	}

}
