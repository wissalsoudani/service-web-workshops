package esprit.tn.soa.graphql;

import java.util.List;

import com.coxautodev.graphql.tools.GraphQLRootResolver;

import esprit.tn.soa.entyty.Student;
import esprit.tn.soa.repository.StudentRepository;

public class Query implements GraphQLRootResolver{ 
	
	private final StudentRepository studentRepository ;

	public Query(StudentRepository studentRepository) {
		this.studentRepository = new StudentRepository();
		
	}
	
	public List<Student> allStudents(){
		return studentRepository.getAllstudents();
	} 
	
	

}
