package esprit.tn.soa.repository;

import java.util.ArrayList;
import java.util.List;

import esprit.tn.soa.entyty.Student;

public class StudentRepository {
	private final List<Student> studnets;

	
	public StudentRepository() {
		
		studnets= new ArrayList<Student>();
		studnets.add(new Student("0123456789","Test","Test@esprit.tn"));
		studnets.add(new Student("225456789","Tet","Te@esprit.tn"));
		
	}
	
	public List<Student> getAllstudents(){
		return studnets;
	}
	
	public void saveStudent(Student student) {
		studnets.add(student);
	}

	
	
	

}
