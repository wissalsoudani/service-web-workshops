package esprit.tn.soa.graphql;



import javax.servlet.annotation.WebServlet;

import com.coxautodev.graphql.tools.SchemaParser;

import esprit.tn.soa.repository.StudentRepository;
import graphql.schema.GraphQLSchema;
import graphql.servlet.SimpleGraphQLServlet;

@WebServlet(urlPatterns ="/graphql")
public class GrapheQLEndpoint extends SimpleGraphQLServlet {


	public GrapheQLEndpoint() {
		super(buildSchema());
		// TODO Auto-generated constructor stub
	}

	private static GraphQLSchema buildSchema() {
		// TODO Auto-generated method stub
		StudentRepository studentrepository = new StudentRepository();
		return SchemaParser.newParser().file("schema.graphqls").resolvers(new Query(studentrepository)).build().makeExecutableSchema();
			
	}
}
